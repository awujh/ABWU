<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가 
include_once('../_head.php');
?>
<h2 class="page-title">
	<strong>로그 관리</strong>
	<span>Log management</span>
</h2>