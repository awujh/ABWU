<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

define('G5_JS_VER',  '171003');
define('G5_CSS_VER', '171003');
?>