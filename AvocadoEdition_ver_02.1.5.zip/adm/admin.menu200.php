<?php
$menu['menu200'] = array (
    array('200000', '회원관리', G5_ADMIN_URL.'/member_list.php', ''),
    array('200100', '회원관리', G5_ADMIN_URL.'/member_list.php', ''),
	array('200200', '활동량관리', G5_ADMIN_URL.'/action_list.php', ''),

    array('200800', '접속자집계', G5_ADMIN_URL.'/visit_list.php', ''),
    array('200810', '접속자검색', G5_ADMIN_URL.'/visit_search.php', ''),
    array('200820', '접속자로그삭제', G5_ADMIN_URL.'/visit_delete.php', ''),
	array('200900', '투표관리', G5_ADMIN_URL.'/poll_list.php', '')
);
?>