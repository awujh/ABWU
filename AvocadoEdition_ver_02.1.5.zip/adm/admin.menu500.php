<?php
$menu['menu500'] = array (
	array('500000', '아이템 관리', ''.G5_ADMIN_URL.'/shop_list.php', ''),
	array('500100', '상점관리', ''.G5_ADMIN_URL.'/shop_list.php', ''),
	array('500200', '아이템관리', ''.G5_ADMIN_URL.'/item_list.php', ''),
	array('500210', '뽑기 관리', ''.G5_ADMIN_URL.'/explorer_list.php', ''),
	array('500220', '레시피 관리', G5_ADMIN_URL.'/recipi_list.php', ''),
	array('500300', '아이템 보유현황', ''.G5_ADMIN_URL.'/inventory_list.php', ''),
	array('500400', '아이템 구매기록', ''.G5_ADMIN_URL.'/order_list.php', ''),
	array('500900', $config['cf_money'].' 관리', ''.G5_ADMIN_URL.'/point_list.php', ''),
);


?>